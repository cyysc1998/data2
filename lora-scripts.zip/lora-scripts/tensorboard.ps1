.\venv\Scripts\activate

tensorboard --logdir=.\logs